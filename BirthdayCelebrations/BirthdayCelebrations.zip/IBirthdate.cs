﻿namespace BirthdayCelebrations
{
    public interface IBirthdate
    {
        public string BirthDate { get; set; }
    }
}
