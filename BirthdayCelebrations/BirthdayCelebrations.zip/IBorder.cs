﻿namespace BirthdayCelebrations
{
    public interface IBorder
    {
        public string ID { get; set; }

    }
}
